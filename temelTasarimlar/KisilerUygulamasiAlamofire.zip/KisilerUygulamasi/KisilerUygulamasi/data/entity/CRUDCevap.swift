//
//  CRUDCevap.swift
//  KisilerUygulamasi
//
//  Created by ÖMER  on 16.03.2024.
//

import Foundation

class CRUDCevap: Codable{
    var success:Int?
    var message:String?
}
