//
//  Anasayfa.swift
//  KisilerUygulamasi
//
//  Created by ÖMER  on 1.03.2024.
//

import UIKit

class Anasayfa: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func detayButton(_ sender: Any) {
        var kisi = Kisiler(kisi_id: 1, kisi_ad: "Ömer", kisi_tel: "9213931")
        performSegue(withIdentifier: "toDetay", sender: kisi)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toDetay"{
            if let kisi = sender as? Kisiler{
                let gidilecekVC = segue.destination as! KisiDetay
                gidilecekVC.kisi = kisi
            }
        }
    }
    

}
