//
//  KisilerHucre.swift
//  KisilerUygulamasi
//
//  Created by ÖMER  on 1.03.2024.
//

import UIKit

class KisilerHucre: UITableViewCell {

    
    @IBOutlet weak var labelKisiAd: UILabel!
    @IBOutlet weak var labelKisiTel: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
